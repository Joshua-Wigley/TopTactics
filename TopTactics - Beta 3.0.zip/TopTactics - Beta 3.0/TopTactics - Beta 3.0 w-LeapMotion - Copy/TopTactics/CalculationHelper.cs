﻿using System.Linq;
using System.Windows;
using Leap;


namespace TopTactics
{
    public static class CalculationHelper
    {
        //Here we set the method for point, and use the the FingerList and Screen options from the Leap.cs class
        public static Point GetNormalizedXAndY(FingerList fingers, Screen screen)
        {
            //We set a var for defining the x and y coodinates of the fingers within the motion sensor
            var xNormalized = screen.Intersect(fingers[0], true, 1.0F).x;
            var yNormalized = screen.Intersect(fingers[0], true, 1.0F).y;

            //x = xNormalised multiplised the screen width via pixels
            var x = (xNormalized * screen.WidthPixels);

            //the Y coodinates is configured from screen height taken away from the result of ynormalised multiplied by screen height pixels.
            var y = screen.HeightPixels - (yNormalized * screen.HeightPixels);

            //The application then returns new coodinates which are the result of normalised x and normalised y
            return new Point() { X = x, Y = y };
        }

    }
}

