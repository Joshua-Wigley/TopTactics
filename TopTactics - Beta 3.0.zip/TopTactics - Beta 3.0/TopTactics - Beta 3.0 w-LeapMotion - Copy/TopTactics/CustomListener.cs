﻿using System;
using System.Threading.Tasks;
using Leap;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;

namespace TopTactics
{
    public class CustomListener : Listener
    {

        //Here we import a DLL which allows us to set keyboard events
        [DllImport("user32.dll", SetLastError = true)]
        static extern void keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);

       //Here we create a new instace of frame
        private Leap.Frame lastFrame = new Leap.Frame();

        //Here are a list of variables that are defined to assist with the motion tracking
        public event Action<FingerList> leapRegisterFingers;
        public event Action<GestureList> fingerGesture;
        private long timeNow;
        private long timePrevious;
        private long timeDifference;

        //Each "On" Method is needed with the Leap Motion, here we create a method for On initialisation and On Connect
        public override void OnInit(Controller controller) { }

        public override void OnConnect(Controller controller)
        {
            try
            {
 //Get all the gestures available in the dictionary, and enable the gestures
            foreach (var gesture in (Gesture.GestureType[])Enum.GetValues(typeof(Gesture.GestureType)))
                controller.EnableGesture(gesture);
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        //Methods for when the controller disconnects and exits
        public override void OnDisconnect(Controller controller) 
        {
            try
            {
     //If the controller disconnects during the applications running time a message appears to the user.
            System.Windows.MessageBox.Show("Leap controller has disconnected, please reattach controller", "Warning!", MessageBoxButton.OK, MessageBoxImage.Asterisk);

            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
       
        }

        public override void OnExit(Controller controller) { }


        //Here a method is created to get the information of each frame.
        public override void OnFrame(Controller controller)
        {
                      
            var frame = controller.Frame();
            //We get the time of the frame and it's time stamp
            timeNow = frame.Timestamp;

            //Register the time difference so that the application knows when to check the next frame from the Leap
            timeDifference = timeNow - timePrevious;

            //If there are no hands detected return nothing
            if (frame.Hands.IsEmpty) return;

            timePrevious = frame.Timestamp;

            //If the time difference is 500 or less than return nothing, if they're more then start a new Threading task and get the gesture and finger data from the frame
            if (timeDifference < 500) return;
            // Run async
            if (frame.Gestures().Count > 0)
                Task.Factory.StartNew(() => fingerGesture(frame.Gestures()));
            if (frame.Fingers.Count > 0)
                Task.Factory.StartNew(() => leapRegisterFingers(frame.Fingers));


            //////////////////////////////////////////////////////////////////////////
            //                            SWIPE LOGIC                              //
            ////////////////////////////////////////////////////////////////////////
            
           if (lastFrame == frame) return;


            GestureList Gestures = (lastFrame.IsValid == true) ? frame.Gestures(lastFrame) : frame.Gestures();

            lastFrame = frame;

            for (int i = 0; i < Gestures.Count; i++)
            {
                //If gesture type of swipe is detected then create a new swipe gesture.
                if (Gestures[i].Type == Gesture.GestureType.TYPESWIPE && Gestures[i].State == Gesture.GestureState.STATESTOP)
                {
                    SwipeGesture Swipe = new SwipeGesture(Gestures[i]);

                    //If a swipe is detected coming from the right hand side then run this segment of code
                    if (Swipe.Direction.x < (Leap.Vector.Right.x + .1) && Swipe.Direction.x > (Leap.Vector.Right.x - .1))
                    {
                        Environment.Exit(0);
                      
                       
                    }
                    //If a swipe is detected from the left hand side detect this segment of code.
                    if (Swipe.Direction.x < (Leap.Vector.Left.x + .1) && Swipe.Direction.x > (Leap.Vector.Left.x - .1))
                    {
                     System.Diagnostics.Process.Start("C:/TopTactics");
                    }
                }


            }
        }
    }
}


