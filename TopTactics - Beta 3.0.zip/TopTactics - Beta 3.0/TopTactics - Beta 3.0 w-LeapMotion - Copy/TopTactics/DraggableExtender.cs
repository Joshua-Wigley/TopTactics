﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Diagnostics;

namespace TopTactics
{
    class DraggableExtender
    {
        public class DraggableExtenders : DependencyObject
        {
            //This is the properpty is composed as readonly, we will access this within the draggableextender.cant drag function

            public static readonly DependencyProperty CanDragProperty =
                DependencyProperty.RegisterAttached("CanDrag",
                typeof(bool),
                typeof(DraggableExtenders),
                new UIPropertyMetadata(false, OnChangeCanDragProperty));

            // We then set the the static method for set 
            public static void SetCanDrag(UIElement element, bool o)
            {
                try
                {
                element.SetValue(CanDragProperty, o);
                }
                catch (Exception ex)
                {

                    System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                
            }

            // we set the static method for get
            public static bool GetCanDrag(UIElement element)
            {
                return (bool)element.GetValue(CanDragProperty);
            }

            //This areas is sued when the CanDrag propery is set. We check the element and if its a UI element within a canvas it is set up to the mouse events.

            private static void OnChangeCanDragProperty(DependencyObject d, DependencyPropertyChangedEventArgs e)
            {
                
                UIElement element = d as UIElement;
                if (element == null) return;

                if (e.NewValue != e.OldValue)
                {
                    if ((bool)e.NewValue)
                    {
                        element.PreviewMouseDown += element_PreviewMouseDown;
                        element.PreviewMouseUp += element_PreviewMouseUp;
                        element.PreviewMouseMove += element_PreviewMouseMove;
                    }
                    else
                    {
                        element.PreviewMouseDown -= element_PreviewMouseDown;
                        element.PreviewMouseUp -= element_PreviewMouseUp;
                        element.PreviewMouseMove -= element_PreviewMouseMove;
                    }
                }
            }

            // Here we check to see whether we're dragging or not
            private static bool _isDragging = false;
 
            //We check to see the offset from the top and left of the item that's dragged and when the mouse down occurs
            private static Point _offset;

            //This event occurs when the mouse button is pressed on a specific element thats being hooked
            static void element_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
            {
                try
                {

             
                //We do this to ensure it's a framework element as we'll need to get access to the visual tree
                FrameworkElement element = sender as FrameworkElement;
                if (element == null) return;

     
                //Here we start dragging and this gets the offset of the mouse in relation to the element.
                _isDragging = true;
                _offset = e.GetPosition(element);  
                
                }
                catch (Exception ex)
                {

                    System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                }
            }

 
            //This event occrus when the mouse is moved over the element.
            private static void element_PreviewMouseMove(object sender, MouseEventArgs e)
            {
                try
                {

              
                //If we're not dragging then nothing happens
                if (!_isDragging) return;

                FrameworkElement element = sender as FrameworkElement;
                if (element == null) return;

                Canvas canvas = element.Parent as Canvas;
                if (canvas == null) return;

    
                //Get the position of the mouse that is related to the canvas
                Point mousePoint = e.GetPosition(canvas);

                //We then offset the mouse position by the original offest position.
                mousePoint.Offset(-_offset.X, -_offset.Y);

                // move the element on the canvas
                element.SetValue(Canvas.LeftProperty, mousePoint.X);
                element.SetValue(Canvas.TopProperty, mousePoint.Y);
                
                }
                catch (Exception ex)
                {

                    System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                }
            }

            // This method then occurs when the mouse is released.
            private static void element_PreviewMouseUp(object sender, MouseButtonEventArgs e)
            {
                try
                {
                _isDragging = false;
                }
                catch (Exception ex)
                {

                    System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                
            }

        }
    }
}
