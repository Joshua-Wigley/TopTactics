﻿using System.Collections.Generic;
using Leap;

namespace TopTactics
{
    public static class LeapGestures
    {
        //A Dictionary is configured so that the application knows which gestures have been configured to be used.
        public static readonly Dictionary<Gesture.GestureType, string> GestureTypesLookUp = new Dictionary<Gesture.GestureType, string>()
                                     {
                                         {Gesture.GestureType.TYPEKEYTAP,"Tap gesture"},
                                         {Gesture.GestureType.TYPECIRCLE, "Circle gesture"},
                                         {Gesture.GestureType.TYPESWIPE, "Swipe gesture"},
                                         {Gesture.GestureType.TYPESCREENTAP, "Screen tap"}
                                     };
    }
}
