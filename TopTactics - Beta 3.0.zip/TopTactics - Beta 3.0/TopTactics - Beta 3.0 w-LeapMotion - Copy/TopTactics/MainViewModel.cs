﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Threading;
using Leap;
using System.Windows.Input;
using Vector = Leap.Vector;


namespace TopTactics
{
    class MainViewModel
    {
        //Here we create some variables which are related to the 3 classes involved with the Leap Motion and the Leap SDK.
        private static Controller _controller;
        private static CustomListener _listener;
        private bool _enableMouse;

        private readonly Dispatcher _dispatcher;
        public modelPropertyChanger propertyModel;


        public MainViewModel(Controller controller, CustomListener listener, modelPropertyChanger propModel)
        {
            try
            {
            propertyModel = propModel;
            //Here we define that _listener inherits data from the Custom LIstener class
            _listener = listener;
            _controller = controller;
            _controller.AddListener(_listener);
            _dispatcher = Application.Current.Dispatcher;
            RegisterEvents();

            //We set it so that the mouse is set to false so that no unintentional movement occur
            _enableMouse = false;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           

        }

        void RegisterEvents()
        {
            try
            {
 //Here we register the events made on the leap device, in this case we are checking for gestures and fingers
            _listener.leapRegisterFingers += OnFingersRegistered;
            _listener.fingerGesture += OnGestureMade;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        public void OnClosing(object sender, CancelEventArgs cancelEventArgs)
        {
            try
            {
   //When the leap motion closes down it removes the listener and then disposes of both variables _listener and _controller
            _controller.RemoveListener(_listener);
            _controller.Dispose();
            _listener.Dispose();
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
         
        }

        public void MouseOnDown(object sender, RoutedEventArgs routerEventArgs)
        {
            try
            {
//Here we enable the mouse when MouseOnDown is detected, or in the Leaps Case the velocity tip is correct
            _enableMouse = true;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            

        }

        void OnGestureMade(GestureList gestures)
        {
            try
            {
  //For each gesture that is made, look up in the Gesture dictionary that has been set so it can detect if the gesture is a valid movement or not
            foreach (var gesture in gestures)
                propertyModel.GestureMade = LeapGestures.GestureTypesLookUp[gesture.Type];
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        void OnFingersRegistered(FingerList fingers)
        {
            try
            {


                //Here we register the screen, coodinates, and fingers.
                var screen = _controller.LocatedScreens.ClosestScreenHit(fingers[0]);
                var coordinate = CalculationHelper.GetNormalizedXAndY(fingers, screen);

                _dispatcher.Invoke(new Action(() =>
                {

                }));
                //We set the leap as mouse using the fingers that are detected and the coodinates of the screen.
                SetLeapAsMouse(fingers, coordinate);

            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        }

        void UpdateUIProperties(Point coordinate)
        {
            try
            {
  //Here we updates the UI Properties of the property model
            propertyModel.CanvasLeft = coordinate.X;
            propertyModel.CanvasTop = coordinate.Y;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }



        void SetLeapAsMouse(FingerList fingers, Point coordinate)
        {
            try
            {
   if (!_enableMouse) return;
            //Here it detects that whichever screen the device is located on user the closest finger as the cursor
            var screen = _controller.LocatedScreens.ClosestScreenHit(fingers[0]);
            if (screen == null || !screen.IsValid) return;

            //We then enable the leap as the cursor and enable clicking with the device.
            EnableLeapAsCursor(coordinate, fingers);
            EnableClickWithLeap(coordinate, fingers);
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }
         
        }

        static void EnableLeapAsCursor(Point coordinate, FingerList fingers)
        {
            try
            {
  //Here we define the TipVelocity.Magnitude which enables us to configure how much tolerance the device will take with juddering and movements
            if ((int)fingers[0].TipVelocity.Magnitude <= 25) return;
            LeapAsMouse.SetCursorPos((int)coordinate.X, (int)coordinate.Y);
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        void EnableClickWithLeap(Point coordinate, FingerList fingers)
        {
            try
            {
   //Here the leap device will concur whether 3 fingers have been detected or not
            if (fingers.Count != 3) return;
            {
                //If 3 fingers are detected we use the class LeapAsMouse and add an mouse event to the click event, in this case we are placing a left mouse click on the coodinates of X and Y
                LeapAsMouse.mouse_event(0x0002 | 0x0004, 0, (int)coordinate.X, (int)coordinate.Y, 0);
            }

            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
         





        }

    }
}


    



