﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Navigation;
    using System.Windows.Shapes;
    using System.IO;
    using System.Diagnostics;
    using System.Runtime.InteropServices;
    using System.Drawing;
    using System.Windows.Forms;
    using System.Globalization;
    using Microsoft.Win32;
    using System.Windows.Media.Effects;
    using System.Windows.Controls.Primitives;
    using Leap;


    namespace TopTactics
    {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //A list of variables that assist with defining brush and stroke colour amongst other features
        bool paint;
        bool isPressed = false;
        int colorOperation;
        System.Windows.Media.Brush brushColour;
        System.Windows.Media.Brush strokeColour;
        int brushType;
        System.Windows.Point startPosition;


        public MainWindow()
        {
            InitializeComponent();
            try
            {
                //Here we define more variables so that the application does begin to paint onto the canvas straight away.
                paint = false;
                colorOperation = 0;
                brushType = 1;

                //Creates a folder within the "C" drive named TopTacitcs, primarily designed for placing the saved tactics within
                string folderName = @"c:\TopTactics";

                //Names subfolders N64 and SNES
                string tacticsPath = System.IO.Path.Combine(folderName, "Saved Tactics");

                //Then Creates the two new created subfolders
                System.IO.Directory.CreateDirectory(tacticsPath);


                // Here a new MainView Model is created also including the "Controller, CustomListener, modelPropertyChanger classes 
                var viewModel = new MainViewModel(new Controller(), new CustomListener(), new modelPropertyChanger());

                //Here we set the DataContext as the viewmodel, including information off of model properly changer
                DataContext = viewModel.propertyModel;

                //Initiates a closing sequence so that the program does not crash on closing
                Closing += viewModel.OnClosing;

                //Here we load up the logic so that the Leap Motion can register a left mouse click
                leapCanvas.Loaded += viewModel.MouseOnDown;



            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {



            //Here we define brushesType as a class of system drawing brushes
            Type brushesType = typeof(System.Drawing.Brushes);

            //We get the property information and define properties as the the properties or the brush type.
            PropertyInfo[] properties = brushesType.GetProperties();

            //Here we define that whatever property info within the brushes is added to the combo lists outlayercombobox and fillcombobox
            foreach (PropertyInfo info in properties)
            {
                fillComboBox.Items.Add(info);
                outerLayerComboBox.Items.Add(info);
            }


        }




        public void sportsInkCanvas_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            //We define paint as false for when the mouse has left the canvas
            paint = false;
        }

        private void sportsInkCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            //Paint is defined as fault so that when the mouse buttons are up they do not draw 
            paint = false;
        }

        private void sportsInkCanvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //Paint is now defined as true for when the mouse button is clicked down on the canvas
            paint = true;

            //If statement is invoked so that the application knows how to process on click
            if (paint == true)
            {

                //"P" represents the X & Y coodinates of the 2 dimensional space.
                System.Windows.Point p;

                //colourOperation is now set to one so that it gets the coodinates of the inkCanvas
                if (colorOperation == 1)
                {

                    p = e.GetPosition(sportsInkCanvas);

                    if (brushType == 1)
                    {

                        try
                        {
  //We have created an Ellipse shape that has it's colours set from whenever the user selects stroke and brush colours.
                        Ellipse myPlayer = new Ellipse();
                        myPlayer.Stroke = strokeColour;
                        myPlayer.Fill = brushColour;
                        //The stroke thickness is
                        myPlayer.StrokeThickness = 3;
                        //Height and Width settingsare defined
                        myPlayer.Width = 50;
                        myPlayer.Height = 50;
                        //Here we define the margin of the chosen shape.
                        myPlayer.Margin = new Thickness(p.X, p.Y, 0, 0);

                        //We then place that line on the canvas
                        sportsInkCanvas.Children.Add(myPlayer);

                        }
                        catch (Exception ex)
                        {

                           

                                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            

                        }
                      
                    }
                    //Here we define the brushType so that the application knows which brush type to use.
                    else if (brushType == 2)
                    {
                        try
                        {
//Create a new shape which is a line
                        Line directionalLineHorizontal = new Line();
                        directionalLineHorizontal.Stroke = strokeColour;
                        //The coodinates of the shape xso the placement of the shape is correct, adding the 200 adds to the length of the line.
                        directionalLineHorizontal.X1 = p.X + 200;
                        directionalLineHorizontal.X2 = p.X;
                        directionalLineHorizontal.Y1 = p.Y;
                        directionalLineHorizontal.Y2 = p.Y;
                        directionalLineHorizontal.StrokeThickness = 5;
                        sportsInkCanvas.Children.Add(directionalLineHorizontal);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
                        

                    }
                    else if (brushType == 3)
                    {
                        try
                        {
              //We create a new rectangle with the variable name imagecontainer
                                System.Windows.Shapes.Rectangle imageContainer = new System.Windows.Shapes.Rectangle();
                                //Here we define the width and height of the image container
                                imageContainer.Width = 150;
                                imageContainer.Height = 300;

                                //Here we define an ImageBrush which paints an area with an image
                                ImageBrush myBrush = new ImageBrush();

                                //Here we define the image brush with the image selected in this case it's crossTopWing
                                myBrush.ImageSource = new BitmapImage(new Uri(@"Images\crossTopWing.png", UriKind.Relative)); // Here we have imported a image, so when a user clicks instead of a basic red square etc. It brings up a selected image.
                                imageContainer.Margin = new Thickness(p.X - 135, p.Y - 300, 0, 0);
                                //Here the imagecontainer is instructed to be filled with whatever is within the variable mybrush
                                imageContainer.Fill = myBrush;
                                //The image is then placed on the canvas
                                sportsInkCanvas.Children.Add(imageContainer);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
                  

                    }
                    else if (brushType == 4)
                    {
                        try
                        {
 //As Explained above, we define an rectangle so that an image can be placed within it
                        System.Windows.Shapes.Rectangle imageContainer = new System.Windows.Shapes.Rectangle();
                        imageContainer.Width = 150;
                        imageContainer.Height = 300;
                        ImageBrush myBrush = new ImageBrush();
                        myBrush.ImageSource = new BitmapImage(new Uri(@"Images\crossTopWingInside.png", UriKind.Relative));
                        imageContainer.Margin = new Thickness(p.X - 10, p.Y - 300, 0, 0);
                        imageContainer.Fill = myBrush;
                        sportsInkCanvas.Children.Add(imageContainer);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
                       
                    }
                    else if (brushType == 5)
                    {
                        try
                        {
  //As defined a new line shape is created
                            Line directionalLineVertical = new Line();
                            directionalLineVertical.Stroke = strokeColour;
                            directionalLineVertical.X1 = p.X;
                            directionalLineVertical.X2 = p.X;
                            directionalLineVertical.Y1 = p.Y + 200;
                            directionalLineVertical.Y2 = p.Y;
                            directionalLineVertical.StrokeThickness = 5;
                            sportsInkCanvas.Children.Add(directionalLineVertical);
                        //Here we change the coodinates so that the line is at an angle this time.

                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
                      
                    }

                    else if (brushType == 6)
                    {
                        try
                        {
//As Explained above, we define an rectangle so that an image can be placed within it

                        System.Windows.Shapes.Rectangle imageContainer = new System.Windows.Shapes.Rectangle();
                        imageContainer.Width = 150;
                        imageContainer.Height = 300;

                        ImageBrush myBrush = new ImageBrush();
                        myBrush.ImageSource =
                            new BitmapImage(new Uri(@"Images\crossTopWingBottom.png", UriKind.Relative)); // Here we have imported a image, so when a user clicks instead of a basic red square etc. It brings up a selected image.
                        imageContainer.Margin = new Thickness(p.X - 130, p.Y, 0, 0);
                        imageContainer.Fill = myBrush;
                        sportsInkCanvas.Children.Add(imageContainer);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
                        
                    }

                    else if (brushType == 7)
                    {
                        try
                        {
   //As Explained above, we define an rectangle so that an image can be placed within it

                        System.Windows.Shapes.Rectangle imageContainer = new System.Windows.Shapes.Rectangle();
                        imageContainer.Width = 150;
                        imageContainer.Height = 300;

                        ImageBrush myBrush = new ImageBrush();
                        myBrush.ImageSource =
                            new BitmapImage(new Uri(@"Images\crossTopWingBottomInside.png", UriKind.Relative)); // Here we have imported a image, so when a user clicks instead of a basic red square etc. It brings up a selected image.
                        imageContainer.Margin = new Thickness(p.X - 10, p.Y, 0, 0);
                        imageContainer.Fill = myBrush;
                        sportsInkCanvas.Children.Add(imageContainer);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
                     
                    }
                    else if (brushType == 8)
                    {
                        try
                        {
          //Here we change the coodinates so that the line is at an angle this time.

                        Line directionalLineD2L = new Line();
                        directionalLineD2L.Stroke = strokeColour;
                        directionalLineD2L.X1 = p.X + 200;
                        directionalLineD2L.X2 = p.X;
                        directionalLineD2L.Y1 = p.Y - 100;
                        directionalLineD2L.Y2 = p.Y;
                        directionalLineD2L.StrokeThickness = 5;
                        sportsInkCanvas.Children.Add(directionalLineD2L);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
              
                    }
                    else if (brushType == 9)
                    {
                        try
                        {
 //Here we define an Ellipse like previously except this time we have added a textbox has been added to configure the players name
                        Ellipse myBrush = new Ellipse();
                        myBrush.Fill = brushColour;
                        myBrush.Stroke = strokeColour;
                        myBrush.StrokeThickness = 3;
                        myBrush.Width = 50;
                        myBrush.Height = 50;
                        //Here we define a new textbox with similar syntax as the ellipse
                        System.Windows.Controls.TextBox text = new System.Windows.Controls.TextBox();
                        text.Margin = new Thickness(p.X - 10, p.Y + 50, 0, 0);
                        myBrush.Margin = new Thickness(p.X, p.Y, 0, 0);
                        text.Height = 30;

                        //Here we add the ellipse and text to the canvas.
                        sportsInkCanvas.Children.Add(text);
                        sportsInkCanvas.Children.Add(myBrush);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
                       
                    }
                    else if (brushType == 0)
                    {
                        try
                        {
           //Here we change the coodinates so that the line is at an angle this time
                        Line directionalLineB2T = new Line();
                        directionalLineB2T.Stroke = strokeColour;
                        directionalLineB2T.X1 = p.X;
                        directionalLineB2T.X2 = p.X + 200;
                        directionalLineB2T.Y1 = p.Y;
                        directionalLineB2T.Y2 = p.Y + 100;
                        directionalLineB2T.StrokeThickness = 5;
                        sportsInkCanvas.Children.Add(directionalLineB2T);
                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                        }
             
                    }
                    else if (brushType == 10)
                    {
                        try
                        {
 //Within the highlight tool, we have defined the Ellipse so that it shows the icon underneath the ellipse
                        Ellipse highlightPlayer = new Ellipse();
                        highlightPlayer.Stroke = strokeColour;
                        //We have defined the fill of the shape as trasparent so users can circle theobject of there choicer
                        highlightPlayer.Fill = System.Windows.Media.Brushes.Transparent;
                        highlightPlayer.StrokeThickness = 3;
                        highlightPlayer.Width = 100;
                        highlightPlayer.Height = 100;
                        highlightPlayer.Margin = new Thickness(p.X - 50, p.Y - 50, 0, 0);

                        sportsInkCanvas.Children.Add(highlightPlayer);

                        }
                        catch (Exception ex)
                        {

                            System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            
                        }
                       

                    }
                    
                }
            }
        }

        private void outerLayerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
 //Here define colour operatin as one so that if a colour is selected it allows the user to paint on the tactics board
            colorOperation = 1;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        private void fillComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
 //Here define colour operatin as one so that if a colour is selected it allows the user to paint on the tactics board
            colorOperation = 1;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }


        private void helpLabel_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we create a new instance of help and then show that help window that has been created/
                    Help helpWindow = new Help();
                    helpWindow.Show();
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        
        }

        public static void SaveCanvasToFile(InkCanvas surface, string filename)
        {
            try
            {

            
            //Here we get the boundaries of only the inkcanvas and nothing else in the application
            Rect bounds = VisualTreeHelper.GetDescendantBounds(surface);
            double dpi = 96d;

            //Here we render the width and height of the canvas within pixed format
            RenderTargetBitmap rtb = new RenderTargetBitmap((int)bounds.Width, (int)bounds.Height, dpi, dpi, System.Windows.Media.PixelFormats.Default);

            //A visual object that is render vector graphics onto the screen
            DrawingVisual dv = new DrawingVisual();
            using (DrawingContext dc = dv.RenderOpen())
            {
                //Here we define a new visual brush as the canvas surface
                VisualBrush vb = new VisualBrush(surface);
                //We then draw a rectangle to the correct size of the canvas using the windows point
                dc.DrawRectangle(vb, null, new Rect(new System.Windows.Point(), bounds.Size));
            }
            //Here we render the visual object
            rtb.Render(dv);

            //Here we encode the image into a png format
            BitmapEncoder pngEncoder = new PngBitmapEncoder();

            //Here we set the indivdual frame within an image in this case it's a bitmapFrame that create rtb
            pngEncoder.Frames.Add(BitmapFrame.Create(rtb));

            
                //Here we initiate the saving sequent 
                System.IO.MemoryStream ms = new System.IO.MemoryStream();

                //Here we save the pngEncoder to a specic Memory streams
                pngEncoder.Save(ms);

                //We close that memory stream
                ms.Close();

                //We write that file
                System.IO.File.WriteAllBytes(filename, ms.ToArray());
            }
            //Here we catch the error in case anything incorrect happens
            catch (Exception err)
            {
                //We display the error in a message box, this prevents the system from crashing on most occassions
                System.Windows.MessageBox.Show(err.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }


        }

        private void sportsInkCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            //Here we define the original source before any event has occured, in this case it is an Ellipse
            if (e.OriginalSource is Ellipse)
            {
                Ellipse clickedEllipse = (Ellipse)e.OriginalSource;
                //Here when the elipse is clicked it goes to 0.5 opacity
                clickedEllipse.Opacity = 0.5;
                //if one clicked has occured on top of the child image then remove it
                if (e.ClickCount == 1)
                {
                    //the canvas that has been clicked on is removed
                    sportsInkCanvas.Children.Remove(clickedEllipse);

                }
                else
                {
                    //If is pressed = true
                    //then get the position of the ink canvas and then captures the location of the clicked ellipse.
                    isPressed = true;
                    startPosition = e.GetPosition(sportsInkCanvas);
                    clickedEllipse.CaptureMouse();
                }
            }
        }

        private void fileImage_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
    //Here we define the visibilty of different menus so that it appears as a sleak design, while also stopping the menus overlapping
                subFileMenuCanvas.Visibility = Visibility.Visible;
                subPitchMenu.Visibility = Visibility.Hidden;
                tacticsSubMenu.Visibility = Visibility.Hidden;
                additionalSubMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            

        }

        private void subFileMenuCanvas_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
 //The subfilemenu will hide when the mouse has left it's areas
            subFileMenuCanvas.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }


        private void saveLabel_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
  //Save inkcanvas to file TopTactics.jpg, this enables for quick save and exit features.
            string filename = "TopTactics.jpg";
            SaveCanvasToFile(sportsInkCanvas, filename);
            subFileMenuCanvas.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        private void saveAsLabel_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            
            // Configure save file dialog box
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.FileName = "Image"; // Default file name
            dlg.DefaultExt = ".png"; // Default file extension
            dlg.Filter = "ImageFile (.png)|*.png"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                string filename = dlg.FileName;
                SaveCanvasToFile(sportsInkCanvas, filename);
                subFileMenuCanvas.Visibility = Visibility.Hidden;
            }
        }

        private void openLabel_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            //We clear any children that are currently on the canvas
            sportsInkCanvas.Children.Clear();

            //We begin the process of opening up the file that we want
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            //Here we specify that we are after PNG files, same as the ones we have saved with our pngencoder
            dlg.Filter = "Image Files(*.PNG)|*.PNG";

            if (dlg.ShowDialog() == true)
            {

                sportsInkCanvas.Children.Clear();

                //We create a new imagebrush
                ImageBrush openBackground = new ImageBrush();

                //Here we set the image source as whatever the dlg.filename is.
                openBackground.ImageSource = new BitmapImage(new Uri(@dlg.FileName, UriKind.Relative));

                //we set the background of the canvas as whatever openBackground is.
                sportsInkCanvas.Background = openBackground;
                subFileMenuCanvas.Visibility = Visibility.Hidden;

            }
        }

        private void exitLabel_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
 //We exit the application
            System.Windows.Application.Current.Shutdown();
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        private void footballMenu_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                sportsInkCanvas.Children.Clear();
                //Here we have defined an image brush as a football pitch so that the user can display tactics on that
                ImageBrush footballBackground = new ImageBrush();
                footballBackground.ImageSource = new BitmapImage(new Uri(@"footballPitch.jpg", UriKind.Relative));
                sportsInkCanvas.Background = footballBackground;
                subPitchMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }

        }

        private void rugbyMenu_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                 sportsInkCanvas.Children.Clear();

                //Here we have defined an image brush as a rugby pitch so that the user can display tactics on that

                ImageBrush rugbyBackground = new ImageBrush();
                rugbyBackground.ImageSource = new BitmapImage(new Uri(@"rugbyPitch.jpg", UriKind.Relative));
                sportsInkCanvas.Background = rugbyBackground;
                subPitchMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           

        }

        private void hockeyMenu_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            sportsInkCanvas.Children.Clear();

            //Here we have defined an image brush as a hockey rink so that the user can display tactics on that

            ImageBrush hockeyBackground = new ImageBrush();
            hockeyBackground.ImageSource = new BitmapImage(new Uri(@"hockeyRink.jpg", UriKind.Relative));
            sportsInkCanvas.Background = hockeyBackground;
            subPitchMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void pitchTypeMenu_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
  //Here we set the menus to either visible or hidden so that users can navigate the menu precisely
            subPitchMenu.Visibility = Visibility.Visible;
            subFileMenuCanvas.Visibility = Visibility.Hidden;
            tacticsSubMenu.Visibility = Visibility.Hidden;
            additionalSubMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        private void subPitchMenu_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
  //Sets the subPitch menu to hidden
            subPitchMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        private void toolsLabelButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
        //Here we set the inkCanvas editing mode to nothing so users can start placing the different tools down
            sportsInkCanvas.EditingMode = InkCanvasEditingMode.None;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
    
        }

        private void penLabel_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
          //Here we set the editing mode of the canvas to ink, allowing the user to freely draw on the canvas
            sportsInkCanvas.EditingMode = InkCanvasEditingMode.Ink;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
  
        }

        private void selectTool1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
 //Here we set the editing mode to select so the user can select any item on the canvas
            sportsInkCanvas.EditingMode = InkCanvasEditingMode.Select;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }


        private void tacticsSubMenu_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
    //Here we set the visibility of the tactics sub menu to hidden
            tacticsSubMenu.Visibility = Visibility.Hidden;
            fillColourCover.Visibility = Visibility.Visible;
            strokeColourCover.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        
        }

        private void sportsInkCanvas_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
     //Here we set the visibility of the menus, when the user enters the canvas all the menus become hidden
            tacticsSubMenu.Visibility = Visibility.Hidden;
            subFileMenuCanvas.Visibility = Visibility.Hidden;
            subPitchMenu.Visibility = Visibility.Hidden;
            additionalSubMenu.Visibility = Visibility.Hidden;
            fillColourCover.Visibility = Visibility.Visible;
            strokeColourCover.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
       


        }

        private void footballImage_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
  //set the visibility properpties of the images
            footballOnCanvas.Visibility = Visibility.Visible;
            rugbyOnCanvas.Visibility = Visibility.Hidden;
            puckOnCanvas.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        private void rugbyButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {         
             //set the visibility properpties of the images
            rugbyOnCanvas.Visibility = Visibility.Visible;
            footballOnCanvas.Visibility = Visibility.Hidden;
            puckOnCanvas.Visibility = Visibility.Hidden;

            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
   
        }

        private void hockeyButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //set the visibility properpties of the images
            puckOnCanvas.Visibility = Visibility.Visible;
            rugbyOnCanvas.Visibility = Visibility.Hidden;
            footballOnCanvas.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void additionalMenuButton_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
     //set the visibility properpties of the menus
            additionalSubMenu.Visibility = Visibility.Visible;
            subPitchMenu.Visibility = Visibility.Hidden;
            subFileMenuCanvas.Visibility = Visibility.Hidden;
            tacticsSubMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
       
        }

        private void tacticsMenuButton_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
         //set the visibility properpties of the menus
            tacticsSubMenu.Visibility = Visibility.Visible;
            additionalSubMenu.Visibility = Visibility.Hidden;
            subPitchMenu.Visibility = Visibility.Hidden;
            subFileMenuCanvas.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
   
        }

        private void menuBannerLeft_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
   //set the visibility properpties of the menus
            menuCanvas.Visibility = Visibility.Visible;
            menuBannerLeft.Visibility = Visibility.Hidden;
            menuRightBanner.Visibility = Visibility.Hidden;
            menuLogo.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
         
        }

        private void menuLogo_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
   //set the visibility properpties of the menus and logo
            menuCanvas.Visibility = Visibility.Visible;
            menuBannerLeft.Visibility = Visibility.Hidden;
            menuRightBanner.Visibility = Visibility.Hidden;
            menuLogo.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
         
        }

        private void menuRightBanner_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
 //set the visibility properpties of the menus and logo
            menuCanvas.Visibility = Visibility.Visible;
            menuBannerLeft.Visibility = Visibility.Hidden;
            menuRightBanner.Visibility = Visibility.Hidden;
            menuLogo.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        private void sportsInkCanvas_MouseEnter_1(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
     //set the visibility properpties of the menus and logo
            menuCanvas.Visibility = Visibility.Hidden;
            menuBannerLeft.Visibility = Visibility.Visible;
            menuRightBanner.Visibility = Visibility.Visible;
            menuLogo.Visibility = Visibility.Visible;
            additionalSubMenu.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
       
        }

        private void sportsPlayer_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
    //Here we apply the brushType number to the button, so that it calls that specific tool on click
            brushType = 1;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        

        }

        private void topLeftArrow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
//Here we apply the brushType number to the button, so that it calls that specific tool on click
            brushType = 3;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void topRightArrow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
//Here we apply the brushType number to the button, so that it calls that specific tool on click
            brushType = 4;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void bottomLeftArrow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
//Here we apply the brushType number to the button, so that it calls that specific tool on click
            brushType = 6;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void bottomRightArrow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
 //Here we apply the brushType number to the button, so that it calls that specific tool on click
            brushType = 7;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        private void canvasLeftDirect_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
//Here we apply the brushType number to the button, so that it calls that specific tool on click
            brushType = 5;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void canvasRightDirect_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                //Here we apply the brushType number to the button, so that it calls that specific tool on click
                        brushType = 8;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }
           
        }

        private void canvasBottomLeftDirect_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we apply the brushType number to the button, so that it calls that specific tool on click
                        brushType = 0;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }
            
        }

        private void canvasBottomRightDirect_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
    //Here we apply the brushType number to the button, so that it calls that specific tool on click
            brushType = 2;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }
         
        }

        private void highglightCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {//Here we apply the brushType number to the button, so that it calls that specific tool on click
                brushType = 10;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
          
        }

        private void erasePlayer_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            { 
                //Set the editing mode to the erase to remove the ink on the canvas
            
                sportsInkCanvas.EditingMode = InkCanvasEditingMode.EraseByStroke;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }
           


        }

        private void definePlayer_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            //Here we apply the brushType number to the button, so that it calls that specific tool on click
            try
            {
                brushType = 9;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                ;
            }
            
        }

        private void troubleButton1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                //Here we define a specific process to start on click
                Process.Start(@"LeapMouseMove");
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void redButtonFill_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
        //Here we define the brush colour as a specific colour, this is for the fill colour of the object
                brushColour = System.Windows.Media.Brushes.Red;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
         
        }

        private void yellowButtonFill_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we define the brush colour as a specific colour, this is for the fill colour of the object
                        brushColour = System.Windows.Media.Brushes.Yellow;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void blueButtonFill_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                //Here we define the brush colour as a specific colour, this is for the fill colour of the object
                        brushColour = System.Windows.Media.Brushes.Blue;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        private void whiteButtonFill_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                //Here we define the brush colour as a specific colour, this is for the fill colour of the object
                        brushColour = System.Windows.Media.Brushes.White;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
        }

        private void greenButtonFill_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we define the brush colour as a specific colour, this is for the fill colour of the object
            brushColour = System.Windows.Media.Brushes.Green;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }

        }

        private void blackButtonFill_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we define the brush colour as a specific colour, this is for the fill colour of the object
                    brushColour = System.Windows.Media.Brushes.Black;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }
          
        }

        private void redButtonStroke_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we define the stroke colour as a specific colour, this is for the rim colour of the object
                        strokeColour = System.Windows.Media.Brushes.Red;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void yellowButtonStroke_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we define the stroke colour as a specific colour, this is for the rim colour of the object
                        strokeColour = System.Windows.Media.Brushes.Yellow;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void greenButtonStroke_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we define the stroke colour as a specific colour, this is for the rim colour of the object
                        strokeColour = System.Windows.Media.Brushes.Green;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void blueButtonStroke_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
                //Here we define the stroke colour as a specific colour, this is for the rim colour of the object
                strokeColour = System.Windows.Media.Brushes.Blue;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void whiteButtonStroke_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
        //Here we define the stroke colour as a specific colour, this is for the rim colour of the 
                    strokeColour = System.Windows.Media.Brushes.White;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            
        }

        private void blackButtonStroke_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            //Here we define the stroke colour as a specific colour, this is for the rim colour of the object
                        strokeColour = System.Windows.Media.Brushes.Black;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }


        private void fillColourCover_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
    //Here we define the visibility of the colour covers
            strokeColourCover.Visibility = Visibility.Visible;
            fillColourCover.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
         
        }

        private void strokeColourCover_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
    //Here we define the visibility of the colour covers
            strokeColourCover.Visibility = Visibility.Hidden;
            fillColourCover.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        private void footballCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
        puckOnCanvas.Visibility = Visibility.Hidden;
                    footballOnCanvas.Visibility = Visibility.Visible;
                    rugbyOnCanvas.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                
            }
            
        }

        private void hockeyPuckCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
              puckOnCanvas.Visibility = Visibility.Visible;
                        footballOnCanvas.Visibility = Visibility.Hidden;
                        rugbyOnCanvas.Visibility = Visibility.Hidden;
            }
            catch (Exception)
            {
                
                throw;
            }
          
        }

        private void rugbyBallCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
            puckOnCanvas.Visibility = Visibility.Hidden;
                        footballOnCanvas.Visibility = Visibility.Hidden;
                        rugbyOnCanvas.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            
        }

        private void tacticsSubMenu_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            try
            {
              strokeColourCover.Visibility = Visibility.Visible;
                        fillColourCover.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
          
        }

        private void canvasRightDirect_MouseLeftButtonUp_1(object sender, MouseButtonEventArgs e)
        {
            try
            {
                //Here we apply the brushType number to the button, so that it calls that specific tool on click
                brushType = 8;
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        }
    }
    }
    