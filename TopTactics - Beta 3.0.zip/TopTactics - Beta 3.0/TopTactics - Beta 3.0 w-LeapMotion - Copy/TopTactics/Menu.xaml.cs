﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using Leap;

namespace TopTactics
{
    
    /// <summary>
    /// Interaction logic for Menu.xaml
    /// </summary>
    public partial class Menu : Window
    {
        //Create a new instance of media player
        MediaPlayer player = new MediaPlayer();

        public Menu()


        {

            InitializeComponent();

            //// Here a new MainView Model is created also including the "Controller, CustomListener, modelPropertyChanger classes 
            //var viewModel = new MainViewModel(new Controller(), new CustomListener(), new modelPropertyChanger());

            ////Here we set the DataContext as the viewmodel, including information off of model properly changer
            //DataContext = viewModel.propertyModel;

            ////Initiates a closing sequence so that the program does not crash on closing
            //Closing += viewModel.OnClosing;

            ////Here we load up the logic so that the Leap Motion can register a left mouse click
            //Begin.Loaded += viewModel.MouseOnDown;

           
            
    
            
        }

        private void Exit_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
         //Shuts entire application down.
                    Application.Current.Shutdown();
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
           
            
        }

        private void Begin_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
    //Closes down the menu and shuts off the music, whilst opening up the tactics board application
            MainWindow topTactics = new MainWindow();
            topTactics.Show();
            player.Stop();
            this.Close();
            
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        
            
        }


        private void mediaElement1_MediaEnded(object sender, RoutedEventArgs e)
        {
            //Begin the media element again if it ends whilst the menu is still open
            player.Position = new TimeSpan(0, 0, 1);
            player.Play();
        }

        private void mediaElement1_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
      //Open up the selected music file
            player.Open(new Uri(@"Music/SportsMenu.mp3", UriKind.Relative));
            VideoDrawing menuMusic = new VideoDrawing();
            //Create a music player for the sound to play in
            menuMusic.Rect = new Rect(0, 0, 100, 100);
            menuMusic.Player = player;

            //Begin to play the media element
            player.Play(); 
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
      

        }

        private void Help_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            try
            {
   //Open up the help window when the left mouse button is clicked on the "Help" button
            Help helpWindow = new Help();
            helpWindow.Show();
            }
            catch (Exception ex)
            {

                System.Windows.MessageBox.Show(ex.Message + "." + "", "Error", MessageBoxButton.OK, MessageBoxImage.Error);

            }
         
        }
    }
}
