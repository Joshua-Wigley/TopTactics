﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;

namespace TopTactics
{
    //We use an INotifyPropertyChanged to notify the client that there has been some form of change
    public class modelPropertyChanger : INotifyPropertyChanged
    {
        private double _canvasLeft;

        public double CanvasLeft
        {
            //Here we get the return of _canvasLeft
            get { return _canvasLeft; }

            set
            {
                
                if (value != this._canvasLeft)
                {
                    //_canvasLeft is given the content of whatever value is.
                    _canvasLeft = value;
               
                }
            }
        }

        private double _canvasTop;

        public double CanvasTop
        {
            //Here we get the return of _canvasTop
            get { return _canvasTop; }

            set
            {
                //_canvasTop is given the content of whatever value is.

                if (value != this._canvasTop)
                {
                    _canvasTop = value;
                  
                }
            }
        }

         private string _gestureMade;

        public string GestureMade
        {
            //Here we get the return of _gestureMade
            get { return _gestureMade; }

            set
            {
                if (value != this._gestureMade)
                {
                    //_gestureMade is given the content of whatever value is.

                    _gestureMade = value;
                
                }
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
    }
}
